#ifndef FONT8X8EXT_H
#define FONT8X8EXT_H

#include <avr/pgmspace.h>
extern const unsigned char font8x8ext[];

#endif