#include <avr/pgmspace.h>
#ifndef SHEMATIC_H
#define SHEMATIC_H

extern const unsigned char schematic[];
#endif
